"""
ADK Agent: GeminiAnalysisAgent
-------------------------------
Specialist agent for reasoning over all collected data to produce the final
structured CaseAnalysis. This agent has NO tools — it only synthesises the
context gathered by CaseRetrievalAgent, RAGPlaybookAgent, and ThreatIntelAgent
and produces a validated JSON output conforming to the CaseAnalysis schema.
"""

from __future__ import annotations
import os
from google.adk.agents import LlmAgent
from sentinel.schemas import CaseAnalysis

MODEL = os.getenv("SENTINEL_MODEL", "gemini-2.5-flash")

ANALYSIS_PROMPT = """You are a senior SOC analyst AI embedded in Project Sentinel.

Your ONLY job is to synthesise all the information already gathered by the
specialist agents and produce a final, structured CaseAnalysis JSON report.

You have NO tools. Do not attempt to call any functions.

--- INPUTS AVAILABLE IN SESSION STATE ---
Read the following keys from the session state to inform your analysis:
  - case_context       : Full case metadata, alerts, assets, raw CEF logs
  - playbook_matches   : Top 3 ranked SOAR playbooks from RAG
  - ioc_enrichments    : Per-IoC reputation scores, malware families, MITRE techniques

--- HITL REVISION INSTRUCTIONS ---
If the session state contains `hitl_override_playbook`:
  - You MUST use that playbook as recommended_playbook_id/name.
  - Explain in playbook_rationale why the analyst selected this override.

If the session state contains `hitl_analyst_feedback`:
  - You MUST revise your analysis to address the analyst's feedback.
  - Incorporate their observations into case_summary and analyst_actions_required.

--- OUTPUT REQUIREMENTS ---
Produce a single JSON object that strictly conforms to the CaseAnalysis schema:
  - case_id
  - case_summary                       (3-5 sentence analyst prose)
  - threat_classification              (e.g. "Credential Abuse / Lateral Movement")
  - severity                           (Critical | High | Medium | Low)
  - mitre_techniques                   (list of {technique_id, technique_name, tactic})
  - blast_radius_endpoints             (integer)
  - blast_radius_users                 (integer)
  - recommended_playbook_id            (e.g. PB-003)
  - recommended_playbook_name
  - playbook_rationale                 (1-2 sentences)
  - confidence_score                   (float 0.0-1.0)
  - ioc_enrichments                    (list of enriched IoC objects)
  - analyst_actions_required           (top 3-5 ordered action strings)
  - estimated_containment_time_minutes (integer)

Output ONLY the JSON object. No preamble, no markdown fences, no explanation.
""".strip()

gemini_analysis_agent = LlmAgent(
    name="GeminiAnalysisAgent",
    description=(
        "Synthesises case context, playbook RAG matches, and IoC enrichments "
        "into a final structured CaseAnalysis JSON. No tools — reasoning only."
    ),
    model=MODEL,
    instruction=ANALYSIS_PROMPT,
    output_schema=CaseAnalysis,
    output_key="case_analysis",
)