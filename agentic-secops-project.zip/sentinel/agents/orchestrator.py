"""
SOC Orchestrator — Root LLM Agent for Project Sentinel
"""

from __future__ import annotations
import os
from google.adk.agents import LlmAgent

from sentinel.agents.action_executor import action_executor_agent
from sentinel.agents.case_retrieval import case_retrieval_agent
from sentinel.agents.gemini_analysis import gemini_analysis_agent
from sentinel.agents.rag_playbook import rag_playbook_agent
from sentinel.agents.threat_intel import threat_intel_agent

MODEL = os.getenv("SENTINEL_MODEL", "gemini-2.5-flash")

ORCHESTRATOR_PROMPT = """You are the SOC Orchestrator for Project Sentinel — a next-generation agentic AIOps platform for a bank's Security Operations Centre.

You coordinate a team of specialist AI agents to analyse security incidents end-to-end.
Your role is to strictly follow this delegation sequence.

PIPELINE SEQUENCE:
1. Delegate to `CaseRetrievalAgent` to get the full case context.
2. Delegate to `RAGPlaybookAgent` to find the best playbook.
3. Delegate to `ThreatIntelAgent` to enrich all IoCs.
4. Delegate to `GeminiAnalysisAgent` to synthesize all collected data into a final report.
5. Await HITL approval.
6. If approved, delegate to `ActionExecutorAgent` to execute the response plan.
""".strip()

soc_orchestrator = LlmAgent(
    name="SOCOrchestrator",
    description="Root SOC Orchestrator — coordinates the full Sentinel pipeline across specialist agents, drives LLM reasoning, and manages HITL approval flow.",
    model=MODEL,
    instruction=ORCHESTRATOR_PROMPT,
    sub_agents=[
        case_retrieval_agent,
        rag_playbook_agent,
        threat_intel_agent,
        gemini_analysis_agent,
        action_executor_agent,
    ],
)
